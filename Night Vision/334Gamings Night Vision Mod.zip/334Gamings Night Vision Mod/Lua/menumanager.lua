_G.NvgMod334 = NvgMod334 or {}
NvgMod334.Mod_Path = ModPath
NvgMod334.Save_Path = SavePath .. "NvgMod334.txt"
NvgMod334.Settings = {
	ColorOption = 1,
}

--Stuff
function NvgMod334:GetOption()
	return NvgMod334.Settings.ColorOption
end

--Load
function NvgMod334:Load()
	local file = io.open(NvgMod334.Save_Path,"r")
	if file then
		for setting,value in pairs(json.decode(file:read("*all"))) do
			NvgMod334.Settings[setting] = value
		end
		log("334 Night Vison Mod Loaded")
	else
		NvgMod334:Save()
	end
end

--Save
function NvgMod334:Save()
	local file = io.open(NvgMod334.Save_Path,"w+")
	if file then
		file:write(json.encode(NvgMod334.Settings))
		file:close()
		log("334 Night Vison Mod Saved")
	end
end

--Loc
Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_NvgMod334", function( loc )
	loc:load_localization_file(NvgMod334.Mod_Path.."Loc/english.json")
end)

--Menu
Hooks:Add( "MenuManagerInitialize", "MenuManagerInitialize_NvgMod334", function(menu_manager)
	MenuCallbackHandler.callback_NvgMenu334_Options_ColorChoice = function(self,item)
		local value = tonumber(item:value())
		NvgMod334.Settings.ColorOption = value
		NvgMod334:Save()
	end
	NvgMod334:Load()
	MenuHelper:LoadFromJsonFile(NvgMod334.Mod_Path.."Menu/Options.json", NvgMod334, NvgMod334.Settings)
end)