local RefreshRate = 0.5
local Delay = 0
function Nvg_Function(t)
	if Delay < t then
		Delay = t + RefreshRate
 
		tweak_data.blackmarket.masks[managers.blackmarket:equipped_mask().mask_id].night_vision = {effect = NvgMod334:GetOption() == 1 and "color_night_vision" or "color_night_vision_blue",light = not _G.IS_VR and 0.3 or 0.1}
	end
end

local Old_MenuManager_update = MenuManager.update
function MenuManager:update(t, dt)
	Old_MenuManager_update(self, t, dt)
	Nvg_Function(t)
end